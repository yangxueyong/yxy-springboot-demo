
初始化：
1. 数据库执行 SQL 脚本 /conf/hippo4j_manager.sql
2. 修改数据库相关信息 /conf/application.properties

如果是对已运行 Hippo4j 升级，请查看 /conf/sql-upgrade 目录下，是否有目标版本对应的升级脚本。

启动命令：
- Mac Linux 执行 sh ./bin/startup.sh
- Windows 执行 ./bin/startup.cmd

启动成功后，访问：localhost:6691/index.html

用户名密码：admin/123456
